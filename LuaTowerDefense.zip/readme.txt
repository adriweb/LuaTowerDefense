English Help : (Français : Onglet suivant)

1. Introduction
Thanks for playing LuaTowerDefense !
The first thing you see when you open the game (tab 1.2), is the main menu. From there, you are able to launch a new game (or load one if possible - you'll be asked-), as well as look at some game Stats and About.

2. Playing the game
When you start playing, you'll see a grid representing the map. The goal is to strategically place towers on the roadsides to prevent enemies from reaching the end (red).
The game can be entirely controlled by mouse or keyboard. Arrow keys will allow you to move the selection, and enter to take an action on that selection (mouse pointing and clicking is then the same). To create a tower, select an empty square and click/enter ; you can upgrade (half the cost) and sell (80% of original price) towers : click/enter on them. To launch an enemy wave, click/enter anywhere on the road. There are keybindings for tower creation : 'a' for Air, 'e' for Earth, 'f' for Fire, 'w' for Water.

3. More
You are able to save a game, but to keep it fair (something usually seen on this genre), when you load it, you'll get you money and level back, but not your placed towers !

4. What's next
I've got external map editing/loading, kind of working, but not available in this version.
Better sprites are going to be available soon, as well as smoother enemy movements.
Any feedback is appreciated ;-)

5. Contact :
Adriweb  -  tiplanet.org  or  inspired-lua.org